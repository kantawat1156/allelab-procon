
# FPGA-Flasher
FPGA-Flasher For XC6SLX9

Download from [releases](https://github.com/ouoam/FPGA-Flasher/releases)

Automate flashing XC6SLX9 from *.bit file by drag and drop function

 1. Drag and drop your *.bit file
 2. Select your rom type which your want (Normal,Prom)
 3. Enter 


![Screenshot](https://raw.githubusercontent.com/thanatath/FPGA-Flasher/master/Screenshot.png)
